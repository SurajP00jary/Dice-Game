const number1=Math.floor(Math.random()*6)+1;
console.log(number1)
dicenumber1=`dice${number1}.png`
console.log(dicenumber1)
dicenumber11=`images/${dicenumber1}`
console.log(dicenumber11)
const dice=document.querySelector('.img1')
dice.setAttribute('src',dicenumber11)
const number2=Math.floor(Math.random()*6)+1;
console.log(number2)
dicenumber2=`dice${number2}.png`
console.log(dicenumber2)
dicenumber22=`images/${dicenumber2}`
console.log(dicenumber22)
const dice2=document.querySelector('.img2')
dice2.setAttribute('src',dicenumber22)
if(number1>number2){
  document.querySelector('h1').innerHTML="Player 1 Won";
}
else if(number2>number1){
  document.querySelector('h1').innerHTML='Player 2 Won';

}
else{
  document.querySelector('h1').innerHTML="Drawed"
}